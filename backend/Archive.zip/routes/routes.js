const express = require("express");
const router = express.Router();

const cartRoutes = require("./cart/cartRoute");
const productRoutes = require("./products/productsRoute");
const categoryRoutes = require("./category/categoryRoute");
const biddingRoutes = require("./bidding/biddingRoute");

router.use("/cart", cartRoutes);
router.use("/products", productRoutes);
router.use("/category", categoryRoutes);
router.use("/bidding", biddingRoutes);

module.exports = router;
