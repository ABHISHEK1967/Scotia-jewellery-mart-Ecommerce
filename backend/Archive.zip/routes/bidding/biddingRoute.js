const express = require("express");
const router = express.Router();
const biddingController = require("../../controllers/bidding/biddingController");

router.get("/getAllBiddingProducts", biddingController.getAllBiddingProducts);
router.get("/getAvailableBiddingProducts", biddingController.getAvailableBiddingProducts);
router.get("/getBiddingProductById/:id", biddingController.getBiddingProductById);
router.get("/historyBidding/:userId", biddingController.biddingHistory);
router.post("/createBiddingProduct", biddingController.createBiddingProduct);
router.post("/placeABid", biddingController.placeABid);


module.exports = router;