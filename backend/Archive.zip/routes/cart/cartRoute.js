const express = require("express");
const router = express.Router();
const cartController = require("../../controllers/cart/cartController");

router.get("/getCartDetails", cartController.getCartDetails);

module.exports = router;
