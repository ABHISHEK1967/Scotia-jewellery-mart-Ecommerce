

exports.getCartDetails = async(req,res)=>{
    res.send({"message":"Cart details will be returned"})
}