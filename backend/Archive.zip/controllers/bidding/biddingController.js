const { BiddingProduct } = require("../../models/biddingProducts/biddingProductsModel");
const { Bidders } = require("../../models/biddingProducts/biddersModel");
const cloudinary = require("cloudinary").v2;
var moment = require('moment');

cloudinary.config({
  cloud_name: "dkjbxujnu",
  api_key: "384624719665962",
  api_secret: "v-gEZoflAk5eakpiLrUKFjMr1-U",
});


exports.getAllBiddingProducts = async (req, res) => {
    const biddingProductList = await BiddingProduct.find({});
    if (!biddingProductList) {
      res.send({ message: "No bidding products available"}).status(500);
    }
    res.send({ biddingProducts: biddingProductList });
};

exports.getAvailableBiddingProducts = async (req, res) => {
    //console.log(new Date());
    console.log("Date   ");
    const biddingProductList = await BiddingProduct.find({
        startTime: { $lte: new Date().toISOString() },
        endTime: { $gte: new Date().toISOString() }
    });
    if (!biddingProductList) {
      res.send({ message: "No bidding products available"}).status(500);
    }
    res.send({ biddingProducts: biddingProductList });
};

exports.createBiddingProduct = async (req, res) => {
    const biddingProduct = new BiddingProduct({
        name: req.body.name,
        description: req.body.description,
        images:req.body.images || [],
        startingBidPrice: req.body.startingBidPrice,
        currentBidPrice: req.body.currentBidPrice,
        startTime: req.body.startTime,
        endTime: req.body.endTime
    });

    biddingProduct.save().then((prod) => {
        res.send({ data: prod, success: true }).status(201);
    }).catch((err) => {
        res.send({ error: err, success: false }).status(500);
    });
};

exports.updateBiddingProducts = async (req, res) => {
    const biddingProductDetails = await BiddingProduct.findByIdAndUpdate(
        req.params.id,
        {
            name: req.body.name,
            description: req.body.description,
            images:req.body.images || [],
            startingBidPrice: req.body.startingBidPrice,
            currentBidPrice: req.body.currentBidPrice,
            startTime: req.body.startTime,
            endTime: req.body.endTime
        },
        { new: true }
      );
      if (!biddingProductDetails) {
        res
          .send({
            message:
              "Bididing product for the Id  not found in the inventory and hence couldn't update it",
            success: false,
          })
          .status(500);
      }
      res.send({ biddingProductDetails: biddingProductDetails, success: true }).status(200);
};

exports.getBiddingProductById = async (req, res) => {
    const biddingProductDetails = await BiddingProduct.findById(req.params.id);
      if (!biddingProductDetails) {
        res
          .send({ message: "No products avaiablble for bidding for given ID", success: false })
          .status(500);
      }
      res.send({ biddingProduct: biddingProductDetails, success: true }).status(200);
};

exports.placeABid = async (req, res) => {
  const placeABidParam=new Bidders({
      userId:req.body.userId,
      biddingProductId:req.body.biddingProductId,
      bid_amount:req.body.bid_amount,
      bid_status:req.body.bid_status || null,
  });

  await BiddingProduct.findById(placeABidParam.biddingProductId).then(async(bidProd)=>{
    let timeDiff = moment(moment(bidProd.endTime,"YYYY-MM-DD")).diff(moment().format("YYYY-MM-DD"), 'seconds');
    console.log(timeDiff+ " =========== > ");
    const biddersDetails = await Bidders.find(
      {
          userId: placeABidParam.userId,
          biddingProductId:  placeABidParam.biddingProductId
      }
    );
    
    if(timeDiff>10){
      // allow place a bid
      if(biddersDetails && biddersDetails.length>0){
        //if(biddersDetails[0].bid_status=='INPROCESS'){
          await Bidders.findOneAndUpdate(
            {
                userId: placeABidParam.userId,
                biddingProductId:  placeABidParam.biddingProductId,
                bid_amount: { $lte: placeABidParam.bid_amount } 
            },
            {
              bid_amount: placeABidParam.bid_amount ,
              bid_status:placeABidParam.bid_status
            },
            {new:true}
          ).then(biddersBiddingAmountValidation=>{
            if(biddersBiddingAmountValidation){
              res.send({ biddersDetails: biddersBiddingAmountValidation, success: true }).status(200); 
            }else{
              res.send({ msg: "Bidding Amount is less than last bidded amount", success: false }).status(500);
            }
          }).catch(err=>{
            res.send({ error: err, success: false }).status(500);
          });
        //}
      }else{
        await placeABidParam.save().then((bidders) => {
            res.send({ data: bidders, success: true }).status(201);
        }).catch((err) => {
            res.send({ error: err, success: false }).status(500);
        });
      }
    }else{
      // set status to OVER.
      await Bidders.findOneAndUpdate(
        {
            userId: placeABidParam.userId,
            biddingProductId:  placeABidParam.biddingProductId
        },
        {
          bid_amount: placeABidParam.bid_amount ,
          bid_status: 'OVER'
        },
        {new:true}
      ).then(biddersBiddingAmountValidation=>{
        res.send({ msg: "Bidding Time Elapsed", success: false }).status(500);
      }).catch(err=>{
        res.send({ error: err, success: false }).status(500);
      });
      
    }
  }).catch(err=>{
    console.log(err);
  });
  

  

    
    
};


// bididng history API that returns object
exports.biddingHistory = async (req, res) => {
  //console.log(+" idd");
  let param=req.params.userId;
  const biddingProductDetails = await Bidders.find({userId: param}).populate("biddingProductId");
  console.log(JSON.stringify(biddingProductDetails)+" hula");
  if(biddingProductDetails.length>0){
    res.send({ biddingProduct: biddingProductDetails, success: true }).status(200);
  }else{
    res
    .send({ message: "Please bid to have history!", success: false })
    .status(500); 
  }
  
  /* if(biddingProductDetails>0){
    console.log("Bidding User");
  }  */ 
};
